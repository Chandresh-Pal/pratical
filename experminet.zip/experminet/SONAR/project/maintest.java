import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class MainTest {

    @Test
    public void testSquare() {
        assertEquals(25, Main.square(5));
    }
}
